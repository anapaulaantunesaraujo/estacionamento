import { Cadastroveiculo } from './cadastroveiculo';

describe('Cadastroveiculo', () => {
  it('should create an instance', () => {
    expect(new Cadastroveiculo()).toBeTruthy();
  });
});
