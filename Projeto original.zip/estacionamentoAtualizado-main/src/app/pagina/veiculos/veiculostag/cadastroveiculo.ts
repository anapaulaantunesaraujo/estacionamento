export class Cadastroveiculo {
    marca:string;
    tipo:string;
    modelo:string;
    placa:string;
    renavam:string;
}
