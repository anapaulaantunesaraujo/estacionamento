import { Carrots } from './carrots';

describe('Carrots', () => {
  it('should create an instance', () => {
    expect(new Carrots()).toBeTruthy();
  });
});
