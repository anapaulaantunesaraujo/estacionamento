export class Carrots {
    uid: string;
    marca:string;
    tipo:string;
    modelo:string;
    placa:string;
    renavam:string;
    
}

