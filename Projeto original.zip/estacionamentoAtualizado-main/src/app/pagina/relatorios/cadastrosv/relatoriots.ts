export class Relatoriots {
        uid: string;
        nome:string;
        idade:string;
        pessoa:string;
        cpf:string;
        estado:string;
        cidade:string;
        bairro:string;
        n:string;
        email:string;
        telefone:string;
        tag:string;
        nacimento:Date;
     
}
