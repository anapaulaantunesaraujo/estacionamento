import { Relatoriots } from './relatoriots';

describe('Relatoriots', () => {
  it('should create an instance', () => {
    expect(new Relatoriots()).toBeTruthy();
  });
});
