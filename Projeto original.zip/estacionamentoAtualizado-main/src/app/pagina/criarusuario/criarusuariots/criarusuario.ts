export class Criarusuariots {
    uid: string;
    primeironome:string;
    sobrenome:string;
    email:string;
    senha:string;
    confirmar_senha:string;

}
