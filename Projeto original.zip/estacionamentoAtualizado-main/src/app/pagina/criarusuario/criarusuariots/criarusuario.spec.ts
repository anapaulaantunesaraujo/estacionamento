import { Criarusuario } from './criarusuario';

describe('Criarusuario', () => {
  it('should create an instance', () => {
    expect(new Criarusuario()).toBeTruthy();
  });
});
