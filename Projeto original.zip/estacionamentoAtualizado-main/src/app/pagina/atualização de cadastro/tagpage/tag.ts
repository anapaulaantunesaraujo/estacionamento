export class Tag {
    usuario:string;
}
